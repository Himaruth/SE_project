<template>
  <router-view :key="$route.fullPath"></router-view>
</template>

<script>


export default {
};
</script>

<style>
@import url("../src/assets/style.css");
</style>